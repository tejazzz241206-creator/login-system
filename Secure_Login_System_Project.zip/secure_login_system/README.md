# Secure Login System (Python + Flask)

A beginner-friendly mini project that demonstrates account registration, secure password hashing, login verification, session-based authentication, protected dashboard access, logout, basic login throttling, and security headers.

## 1. Requirements
- Python 3.10 or newer
- Internet connection for the first dependency installation

## 2. Install and run (Windows PowerShell)
Open PowerShell in this project folder and run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
py app.py
```

If PowerShell blocks activation, you can skip activation and use:
```powershell
py -m pip install -r requirements.txt
py app.py
```

Open `http://127.0.0.1:5000` in your browser. Register a new account, then log in.

If `py` is not recognized, install Python from the official Python website and select the option to add Python to PATH during installation.

## 3. Project structure
```text
secure_login_system/
├── app.py
├── requirements.txt
├── README.md
└── templates/
    ├── base.html
    ├── login.html
    ├── register.html
    └── dashboard.html
```

`users.db` is created automatically after the first run. Do not share it because it contains account records (passwords are stored as hashes, not plain text).

## 4. How it works
1. **Registration:** validates the username and password length.
2. **Password storage:** hashes the password with Werkzeug rather than storing the original password.
3. **Login:** looks up the account using a parameterized SQL query and verifies the hash.
4. **Sessions:** records the logged-in user in a signed session cookie.
5. **Access control:** redirects users who are not logged in away from the dashboard.
6. **Login throttling:** temporarily slows repeated failures in this single-process demo.
7. **Security headers:** adds basic browser security headers.

## 5. Test checklist
- Register a username and password with 12+ characters.
- Log in with the correct password; the dashboard should appear.
- Log out; the dashboard should require login again.
- Try an incorrect password; the app should show a generic error.
- Try 5 incorrect attempts for the same username; the demo should temporarily block attempts.
- Stop and restart the app; accounts should remain in `users.db`.

## 6. Important security limitations
This is an educational local demo, **not production-ready authentication**:
- Set a long random `SECRET_KEY` through an environment variable. The included fallback is only for local practice.
- Use HTTPS in deployment and set `HTTPS_ONLY=1`.
- The in-memory login throttle resets when the app restarts and is not shared across multiple workers. Use persistent shared rate limiting in a real deployment.
- Add CSRF protection, email verification, password reset, secure account recovery, audit logging, and security monitoring before production use.
- Use a production WSGI server and secure deployment configuration; never expose Flask's development server directly to the internet.
- Do not test against websites or accounts you do not own or have permission to assess.

## 7. Example environment secret (PowerShell)
Generate a secret locally:
```powershell
py -c "import secrets; print(secrets.token_hex(32))"
```
Copy the output, then set it in your current PowerShell session:
```powershell
$env:SECRET_KEY="paste-your-generated-secret-here"
py app.py
```

## Project description (under 350 characters)
Built a Python Flask secure login web app with user registration, password hashing, session-based authentication, protected dashboard access, logout, basic login-attempt throttling, SQLite storage, and security headers. Demonstrates foundational web authentication and secure coding practices.
