from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from pathlib import Path
import sqlite3
import os
import time

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "users.db"
app = Flask(__name__)
# Set SECRET_KEY in your environment for anything beyond a local demo.
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-only-change-this-secret-key")
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
# Enable only when serving over HTTPS:
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("HTTPS_ONLY", "0") == "1"

MAX_ATTEMPTS = 5
LOCK_SECONDS = 60
attempts = {}  # Demo-only, in-memory throttling; use shared storage in production.


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to view that page.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


@app.after_request
def add_security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; style-src 'self' 'unsafe-inline'; "
        "form-action 'self'; frame-ancestors 'none'; base-uri 'self'"
    )
    return response


@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not (3 <= len(username) <= 30) or not username.replace("_", "").isalnum():
            flash("Username must be 3–30 characters and use only letters, numbers, or underscores.", "danger")
            return render_template("register.html")
        if len(password) < 12:
            flash("Use a password with at least 12 characters.", "danger")
            return render_template("register.html")

        password_hash = generate_password_hash(password)  # Werkzeug uses a password-hashing method.
        try:
            with get_db() as conn:
                conn.execute(
                    "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                    (username, password_hash)
                )
            flash("Account created. You can now log in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("That username is unavailable. Choose another.", "danger")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        now = time.time()
        state = attempts.get(username, {"count": 0, "locked_until": 0})
        if state["locked_until"] > now:
            flash("Too many attempts. Please wait a minute before trying again.", "danger")
            return render_template("login.html")

        with get_db() as conn:
            user = conn.execute(
                "SELECT id, username, password_hash FROM users WHERE username = ?",
                (username,)
            ).fetchone()

        if user and check_password_hash(user["password_hash"], password):
            attempts.pop(username, None)
            session.clear()  # Avoid reusing pre-login session data.
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(url_for("dashboard"))

        state["count"] += 1
        if state["count"] >= MAX_ATTEMPTS:
            state = {"count": 0, "locked_until": now + LOCK_SECONDS}
        attempts[username] = state
        # Same message for unknown username and wrong password.
        flash("Invalid username or password.", "danger")
    return render_template("login.html")


@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", username=session.get("username", "User"))


@app.route("/logout", methods=["POST"])
@login_required
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))


if __name__ == "__main__":
    init_db()
    # Local development only. Do not expose the Flask development server publicly.
    app.run(debug=False, host="127.0.0.1", port=5000)
